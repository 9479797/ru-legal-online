/* Рекламная оценка продвижения и продажи для первой цели. Без сетевых зависимостей. */
window.BookUI = {
  create({ D, S, esc, curForm, saveBar }) {
    const scopes = { promotion: 'Продвижение', sale: 'Продажа' };
    const channels = [
      ['site', 'Свой сайт', 'Страница материала и предложение о покупке.'],
      ['vkshop', 'Товары VK', 'Карточка товара и условия предложения.'],
      ['market', 'Книжный сервис или маркетплейс', 'Карточка книги в выбранном внешнем сервисе.'],
      ['donut', 'VK Донат', 'Регулярная подписка на материалы и дополнения.'],
      ['tgbot', 'Telegram-бот', 'Предложение материала в боте и условия площадки.']
    ];
    const fmt = () => S.format === 'print' ? 'Печатная книга' : 'Цифровой файл';
    const selected = () => channels.find(c => c[0] === S.salePlace) || channels[0];
    const list = a => '<ul>' + a.map(t => '<li>' + esc(t) + '</li>').join('') + '</ul>';
    const box = (title, content, extra = '') => '<section class="note journey ' + extra + '"><h3>' + esc(title) + '</h3>' + content + '</section>';
    const placeId = p => p?.id || selected()[0];
    const incompatible = p => S.format === 'print' && placeId(p) === 'donut';
    function publicationInfo(a, b) {
      if (!b || b.uncommitted) return null;
      const id = b.publicationPlatform || (a?.id === 'bloggers' ? S.publisher || '' : null);
      if (id === null) return null;
      const option = (D.bookPublishers || []).find(p => p.id === id);
      if (!option || id === 'other') return {name:option?.name || 'Не выбрана', risk:'y', needsCheck:true, title:'Уточните площадку публикации', text:'Способ договорённости с блогером не определяет место размещения. Выберите площадку, прежде чем оценивать рекламный путь.'};
      if (id === 'site') return {name:option.name, risk:'g', text:'Это сайт блогера, а не собственный сайт продавца. Отдельно проверьте публикацию, рекламные обязанности и страницу предложения.'};
      const source = D.start.book.find(n => n.id === (id === 'dzen' ? 'rutube' : id));
      return {name:option.name, risk:source.risk, text:source.details, blocked:id === 'instagram', needsCheck:id === 'tiktok', title:id === 'instagram' ? 'Рекламное размещение в Instagram запрещено' : 'Подтвердите текущую допустимость рекламы в TikTok'};
    }
    function publicationIssue(a, b) {
      if (b?.why || b?.uncommitted) return null;
      const info = publicationInfo(a, b);
      return info && (info.blocked || info.needsCheck) ? info : null;
    }
    function publicationNotice(a, b) {
      const info = publicationInfo(a, b);
      return info ? box('Площадка публикации: ' + info.name, '<p>' + esc(info.text) + '</p>', info.risk === 'g' ? '' : 'attention') : '';
    }
    function publicationChoice(a) {
      if (a?.id !== 'bloggers') return '';
      return '<div class="note publication-settings"><label for="publisher">Где выйдет публикация?</label><select id="publisher" aria-describedby="publisher-help"><option value="">Не выбрана</option>' + (D.bookPublishers || []).map(p => '<option value="' + esc(p.id) + '"' + (S.publisher === p.id ? ' selected' : '') + '>' + esc(p.name) + '</option>').join('') + '</select><p id="publisher-help">Выберите площадку, на которой блогер расскажет о вашей книге. Место продажи выбирается отдельно. Для взаимного пиара проверьте оба размещения.</p></div>';
    }
    function giftOutcome(b) {
      return box('Результат: книга передана без обязательства обзора', '<p>Публикация и переходы покупателей не гарантированы. Если обзор появится, оцените его отдельно. При договорённости об обязательном размещении выберите бартер.</p>' + list(b.here.can));
    }
    function verification(p, b) {
      if (b?.id === 'tg-ads' && placeId(p) === 'site') return {title:'Telegram Ads: подтвердите страницу назначения', text:'До запуска подтвердите, поддерживает ли выбранный формат прямую ссылку на сайт. Инструкции платформы описывают назначения неоднозначно. До подтверждения этот маршрут не считается готовым переходом к покупке.'};
      if (S.format !== 'print' && placeId(p) === 'vkshop') return { title: 'Цифровой файл в «Товарах» VK: требуется проверка', text: 'Актуальные правила размещения цифрового файла в каталоге VK не подтверждены. До проверки маршрут к оформлению заказа здесь не показывается. Это не вывод о законодательном запрете. Можно выбрать свой сайт; печатная книга рассматривается отдельно.' };
      if (S.format !== 'print' && placeId(p) === 'market') return { title: 'Электронная книга: уточните книжный сервис', text: 'Выберите конкретный книжный сервис и подтвердите поддержку выбранного формата. Наличие электронных книг на площадке не подтверждает приём произвольного файла от любого продавца. До проверки путь к оформлению здесь не подтверждён; это не законодательный запрет цифровых книг.' + (b?.marketReview ? ' Для перехода из VK также проверьте условия ссылки, а для VK Рекламы — поддержку внешней карточки выбранным форматом.' : '') };
      if (placeId(p) === 'market' && b?.marketReview) return { title: 'Переход на маркетплейс: проверьте условия', text: 'Уточните конкретный маркетплейс и карточку книги. Для VK Рекламы проверьте поддержку внешней ссылки выбранным форматом объявления; для цифрового файла — также правила его размещения на маркетплейсе. После подтверждения условий маршрут ведёт к карточке предложения.' };
      return null;
    }
    const verificationBox = q => box(q.title, '<p>' + esc(q.text) + '</p>', 'attention');
    const serviceConditions = p => placeId(p) === 'donut' ? 'До подключения подтвердите действующие правила Доната для своего сообщества, включая возрастные ограничения. Актуальный текст этих условий пока не подтверждён; схема показывает модель подписки, а не готовность конкретного сообщества к запуску.' : '';
    const productName = p => placeId(p) === 'donut' && S.format !== 'print' ? 'Доступ по подписке' : fmt();
    function sampleItems(p) { return ['Указать объём бесплатного фрагмента и способ получения.', 'Отделить отправку фрагмента от необязательной подписки на рекламные письма.', placeId(p) === 'donut' ? 'Дать переход к условиям подписки: состав материалов, период доступа и регулярность платежей.' : 'Дать понятный переход к полной версии с её ценой и условиями.']; }
    function saleItems() {
      return ['Оценить содержание, оформление и контекст предложения: является ли конкретный материал рекламой.', 'Проверить описание продукта, цену и заявленные условия; сведения в объявлении и в месте продажи должны согласовываться.', 'Для рекламного материала определить применимые требования к содержанию, сведениям о рекламодателе и продавце, маркировке и учёту.', 'Отдельно проверить заявления о результате, скидках, сроках и доступности предложения.', 'Оформление договора, расчёты, чеки и выполнение заказа передать на проверку в проект сопровождения онлайн-бизнеса.'];
    }
    function paymentPath(b, p) {
      const sample = S.sample || (b && b.sample);
      const id = placeId(p);
      const path = id === 'donut' ? ['Предложение подписки', 'Состав, цена и период подписки', 'Условия подключения и прекращения'] : [id === 'tgbot' ? 'Предложение в боте' : S.format === 'print' ? 'Карточка книги' : 'Страница материала', 'Цена и условия предложения', id === 'tgbot' ? 'Переход к оформлению заказа в боте' : 'Переход к оформлению заказа'];
      return (sample ? ['Бесплатный фрагмент'] : []).concat(path);
    }
    function pathway(items) { return '<ol class="journey-path">' + items.map(t => '<li>' + esc(t) + '</li>').join('') + '</ol>'; }
    function navigation() { return '<div class="journey-nav">' + Object.entries(scopes).map(([k, title]) => '<button type="button" class="wbtn" data-book-scope="' + k + '" aria-pressed="' + (S.scope === k) + '">' + title + '</button>').join('') + '</div>'; }
    function outcome(b, p) {
      if (incompatible(p)) return box('Подписка и печатный экземпляр — разные продукты', '<p>Донат открывает доступ к материалам. Для заказа и доставки печатной книги выберите другое место продажи.</p>' + navigation());
      const q = verification(p, b);
      if (q) return verificationBox(q) + ((S.sample || b?.sample) ? box('Бесплатный фрагмент', list(sampleItems(p))) : '') + navigation();
      const transfer = b && b.transfer;
      const republish = b && b.republish;
      const title = republish ? 'Результат: публикация копии' : transfer ? 'Результат: перенос аудитории' : placeId(p) === 'donut' ? 'Как работает подписка' : 'Куда приводит продвижение';
      const content = republish ? '<p>Копия ролика опубликована на площадке «' + esc(p.name) + '». Переход зрителей из исходного канала этим не подтверждён. Для переноса аудитории отдельно проверьте сообщение о другом канале и ссылку на него.</p>' : transfer ? '<p>Человек переходит в «' + esc(p.name) + '». Этот маршрут может завершаться здесь. Если нужно разобрать покупку, отдельно выберите раздел «Продажа» и фактическое место заказа.</p>' : pathway(paymentPath(b, p)) + ((S.sample || b?.sample) ? '<details><summary>Что предусмотреть для бесплатного фрагмента</summary>' + list(sampleItems(p)) + '</details>' : '') + '<p>На этом рекламный маршрут заканчивается. Оформление и выполнение заказа проверяются в проекте сопровождения онлайн-бизнеса.</p>';
      return box(title, content + (serviceConditions(p) && !transfer && !republish ? '<p>' + esc(serviceConditions(p)) + '</p>' : '') + navigation());
    }
    function renderStage() {
      const section = scopes[S.scope];
      const cards = channels.map(([id, title, desc]) => '<button type="button" class="sale-choice' + (selected()[0] === id ? ' chosen' : '') + '" data-sale-place="' + id + '" aria-pressed="' + (selected()[0] === id) + '"><b>' + esc(title) + '</b><span>' + esc(desc) + '</span></button>').join('');
      return box(section + ': ' + productName().toLowerCase(), '<p>Выберите фактическое место заказа. Раздел продвижения и выбранный рекламный маршрут сохраняются.</p><div class="sale-choices">' + cards + '</div>') +
        (incompatible() ? box('Подписка и печатный экземпляр — разные продукты', '<p>Донат открывает доступ к материалам. Для продажи и доставки печатной книги выберите сайт, карточку VK, маркетплейс или отдельно проверяемую модель бота.</p>') : verification() ? verificationBox(verification()) + (S.sample ? box('Бесплатный фрагмент', list(sampleItems())) : '') :
        box('Предложение в месте продажи', pathway(paymentPath())) +
        box('Что проверить в предложении', list(saleItems())) +
        ((S.sample && S.scope === 'sale') ? box('Необязательный бесплатный фрагмент', list(sampleItems())) : '')) +
        (serviceConditions() && !incompatible() ? box('Условия сервиса требуют подтверждения', '<p>' + esc(serviceConditions()) + '</p>', 'attention') : '') +
        (selected()[0] === 'tgbot' ? box('Модель бота требует отдельной проверки', '<p>Наличие платёжной кнопки не подтверждает соблюдение российских требований. Правила Telegram, расчёты, налоги, чеки и обработку данных проверяют раздельно.</p>', 'attention') : '') +
        box('Дальнейшая проверка', '<p>Здесь проверяется рекламная сторона предложения. Документы продажи и выполнение заказа относятся к проекту сопровождения онлайн-бизнеса.</p>' + navigation()) + saveBar();
    }
    function summaryBlocks(b, p, a) {
      const blocks = [['Раздел и формат', [scopes[S.scope] + ' · ' + fmt()]]];
      if (b?.uncommitted) { blocks.push(['Результат', ['Книга передана без обязательства обзора. Публикация и переходы покупателей не гарантированы. Если обзор появится — оцените его отдельно.']]); return blocks; }
      const publication = publicationInfo(a, b);
      if (publication) blocks.push(['Фактическая площадка публикации', [publication.name, publication.text]]);
      const issue = publicationIssue(a, b);
      if (issue) { blocks.push(['Статус маршрута', [issue.title, issue.blocked ? 'Рекламный путь здесь не продолжается.' : 'Готовность рекламного размещения не подтверждена.']]); return blocks; }
      if (a && ['telegram', 'youtube'].includes(a.id)) blocks.push(['Риск исходной площадки', [a.details]]);
      if (a && ['instagram', 'tiktok'].includes(a.id)) blocks.push(['Условия исходной площадки', [a.details]]);
      if (b?.why) { blocks.push(['Результат', [b.review ? 'Требуется проверка. Маршрут покупки не подтверждён.' : 'Предупреждающий тупик. Путь покупки здесь не продолжается.']]); return blocks; }
      if (incompatible(p)) { blocks.push(['Несовместимая модель', ['Донат открывает подписной доступ, а не продаёт и доставляет печатный экземпляр. Выберите место заказа книги.']]); return blocks; }
      const q = verification(p, b);
      if (q) { blocks.push([q.title, [q.text]]); if (S.sample || b?.sample) blocks.push(['Бесплатный фрагмент', sampleItems(p)]); return blocks; }
      if (b?.republish) blocks.push(['Результат', ['Копия ролика опубликована на площадке «' + p.name + '». Переход аудитории этим не подтверждён; покупка в этот итог не включена.']]);
      else if (b?.transfer) blocks.push(['Результат', ['Перенос аудитории в «' + p.name + '». Покупка в этот итог не включена.']]);
      else {
        blocks[0][1] = [scopes[S.scope] + ' · ' + productName(p)];
        blocks.push([placeId(p) === 'donut' ? 'Путь подписчика' : 'Путь до оформления заказа', paymentPath(b, p)]);
        if (serviceConditions(p)) blocks.push(['Условия сервиса требуют подтверждения', [serviceConditions(p)]]);
        if (S.sample || b?.sample) blocks.push(['Бесплатный фрагмент', sampleItems(p)]);
      }
      return blocks;
    }
    function summary() {
      if (incompatible() || verification()) return { title: scopes[S.scope] + ' · ' + fmt(), path: selected()[1], blocks: summaryBlocks(), legal: 'Предлагаемая локальная редакция 24.11.2026 · v8. Это разбор, а не юридическое заключение.' };
      return { title: scopes[S.scope] + ' · ' + productName() + ' · ' + curForm().name, path: selected()[1], blocks: summaryBlocks().concat([['Проверка предложения', saleItems()]]), legal: 'Предлагаемая локальная редакция 24.11.2026 · v8. Это разбор, а не юридическое заключение. Платежи, договоры и нерешённые условия сервисов проверяются под конкретную модель.' };
    }
    return { renderStage, outcome, summaryBlocks, summary, navigation, incompatible, verification, publicationInfo, publicationIssue, publicationNotice, publicationChoice, giftOutcome };
  }
};
