# Источники и пределы локальной редакции

Дата сверки используемых ниже общих правил: 23.11.2026. Тексты норм и
документов ведомств читались в правовых базах. Прямой доступ к отдельным
официальным страницам ФАС и реестрам РКН отсутствовал. Это не проверка
реестров в реальном времени и не полный аудит всех девяти остальных целей.

## Законодательство

- Закон № 38-ФЗ, статья 5: https://www.consultant.ru/document/cons_doc_LAW_58968/f67f81c57fdcdacc2643d19d59369f7e185e1156/
- Статья 8, реквизиты при дистанционной продаже: https://www.consultant.ru/document/cons_doc_LAW_58968/b606ec51a053c12b78e7ab9a8c007fa723e6f321/
- Статья 9, стимулирующие мероприятия: https://www.consultant.ru/document/cons_doc_LAW_58968/7b11ca039c27a1a3999a4f93bed2bcdd9149f906/
- Статья 18, согласие на рекламу: https://www.consultant.ru/document/cons_doc_LAW_58968/f892dec1383709792452f18d36e7043306e2be0a/
- Статья 18.1, учёт и маркировка: https://www.consultant.ru/document/cons_doc_LAW_58968/2c4537e4796f6ff8b2736ed1b0d4fef08e14458e/
- Статья 18.2, рекламные отчисления: https://www.consultant.ru/document/cons_doc_LAW_58968/f5499f6a99f4f1011e473eae3412f6c7f0262387/
- Статья 24, медицинская реклама: https://www.consultant.ru/document/cons_doc_LAW_58968/8fbc3d05dbc778e17bfc1b45fb7339df525c1985/
- Правила № 1963, подача сведений о странице: https://www.consultant.ru/document/cons_doc_LAW_495334/047cc51bf3c54d90f7db4c6aee56808db2302a79/
- Критерии № 1087, реклама и информация: https://www.consultant.ru/document/cons_doc_LAW_510801/72ae25ab72435b3b522ad875b2f290bcbe4faa39/
- Приказ РКН № 68, способы размещения идентификатора: https://sudact.ru/law/prikaz-roskomnadzora-ot-25032025-n-68-ob/
- Правила № 974 в редакции 18.09.2025, включая пункт 10: https://meganorm.ru/mega_doc/dop_fire_update_01112025/0/kodeks_rossiyskoy_federatsii_ob_administrativnykh/6/postanovlenie_pravitelstva_rf_ot_28_05_2022_N_974_red_ot_18.html
- Закон № 436-ФЗ, пределы применения: https://www.consultant.ru/document/cons_doc_LAW_108808/d44bdb356e6a691d0c72fef05ed16f68af0af9eb/
- Закон № 422-ФЗ, статья 8, база НПД: https://www.consultant.ru/document/cons_doc_LAW_311977/c2d36c561e1cb3865295658c7014e0a0d10371cc/

## Позиции и разъяснения ведомств

- ФАС, переходный период для Telegram и YouTube: https://www.consultant.ru/document/cons_doc_LAW_529901/
- Руководство ФАС № 410/24, сети электросвязи: https://www.consultant.ru/document/cons_doc_LAW_482014/d54cdfade7a7dd1f49306a747e3204aa24f7ab41/
- Руководство ФАС № 1079/23: https://www.consultant.ru/document/cons_doc_LAW_478673/
- Письмо РКН № 03-97847, email/push и учёт: https://www.garant.ru/products/ipo/prime/doc/407772345/
- ФНС, НПД и расходы: https://npd.nalog.ru/faq/
- ФНС, выручка посредника и комиссия: https://www.nalog.gov.ru/rn44/news/activities_fts/16569184/

## Условия сервисов — отдельно от закона

- Telegram, цифровые платежи: https://core.telegram.org/bots/payments-stars
- Telegram, условия разработчиков, раздел 6.2: https://telegram.org/tos/bot-developers
- Telegram, анонс Stars от 06.06.2024: https://telegram.org/blog/telegram-stars
- VK, продвижение Дзена: https://vk.company.ru/ru/press/releases/12333/
- Яндекс, формат постов в мессенджерах: https://yandex.com/support/direct/ru/messengers-ads/features

## Что не подтверждено окончательно

Текущий статус ограничений TikTok; первичные судебные акты по отдельным
ссылкам, символике и платежам Meta; некоторые актуальные тарифы и условия
VK, AdBlogger и ОРД; отдельные вопросы периода учёта саморекламы и базы
рекламного сбора. Для них не выдано окончательное разрешение или запрет.

Суммы штрафов исходного сайта не пересчитывались целиком. Отсутствие erid
отделено от отсутствия пометки и сведений о рекламодателе; неподтверждённые
обобщения о ссылках и платежах отмечены «сверить».

Договоры продажи, возвраты, налоги, кассы и персональные данные требуют
проверки под фактическую модель. Сайт показывает необходимые вопросы и
действия, а не заменяет такую проверку.
